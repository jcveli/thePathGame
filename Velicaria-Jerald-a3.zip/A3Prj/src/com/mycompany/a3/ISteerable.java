package com.mycompany.a3;

public interface ISteerable {
	/*
	 * Interface for steerable objects the user can
	 * control to change its outcome 
	 */
	public void changeHeading(char direction);
}
